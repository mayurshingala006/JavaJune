package com.example.JavaJune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaJuneApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaJuneApplication.class, args);
	}

}
